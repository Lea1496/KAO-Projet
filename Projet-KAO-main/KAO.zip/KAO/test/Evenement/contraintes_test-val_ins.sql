/*
-- =========================================================================== A
-- Insertion des tests valides pour les contraintes
-- -----------------------------------------------------------------------------
Produit  : KAO
Version  : 0.0.0
Statut   : en vigueur
-- =========================================================================== A
*/
--
set schema 'evenement';
--
-- Ces tests sont présents dans table_test_val
/*
-- =========================================================================== Z
Contributeurs :
  (LR) Lea.Roy4@USherbrooke.ca
  (MBL)Matis.BerubeLauziere@USherbrooke.ca
  (GK) Kosg1101@usherbrooke.ca

Tâches projetées :

Tâches réalisées :
  2023-11-16 (LR) : Création
-- -----------------------------------------------------------------------------
-- Fin de contraintes_test-val_ins.sql
-- =========================================================================== Z
*/
